package com.example.a18819574_1.acumulativa;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText editNick;
    EditText editPass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editNick = (EditText) findViewById(R.id.editNick);
        editPass = (EditText) findViewById(R.id.editPass);
    }

    public void Ingresar(View v){
        Intent ingreso = new Intent(this,inicio.class);
        ingreso.putExtra("dato", editNick.getText().toString());
        ingreso.putExtra("dato2", editPass.getText().toString());
        startActivity(ingreso);
    }
}
