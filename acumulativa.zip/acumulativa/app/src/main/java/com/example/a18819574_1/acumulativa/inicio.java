package com.example.a18819574_1.acumulativa;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class inicio extends AppCompatActivity {

    EditText editn1, editn2;
    TextView txtResultado;
    RadioButton rbSumar, rbRestar, rbMultiplicar, rbDividir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);
        editn1 = (EditText) findViewById(R.id.editn1);
        editn2 = (EditText) findViewById(R.id.editn2);
        rbSumar = (RadioButton) findViewById(R.id.rbSumar);
        rbRestar = (RadioButton) findViewById(R.id.rbRestar);
        rbMultiplicar = (RadioButton) findViewById(R.id.rbMultiplicar);
        rbDividir = (RadioButton) findViewById(R.id.rbDividir);
        txtResultado = (TextView) findViewById(R.id.txtResultado);
        String dato = getIntent().getStringExtra("dato");
        String dato2 = getIntent().getStringExtra("dato2");
        String[] arreglo = new String[2];
        arreglo[0]="root";
        arreglo[1]="1";
        if(dato.equals(arreglo[0])&&dato2.equals(arreglo[1])){
            Toast.makeText(this, "Bienvinido", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "No existe este usuario", Toast.LENGTH_SHORT).show();
        }
    }
    public void Calcular(View v){
        int n1 = Integer.parseInt(editn1.getText().toString());
        int n2 = Integer.parseInt(editn2.getText().toString());
        if (rbSumar.isChecked()==true){
            int Resultado = n1 + n2;
            txtResultado.setText("El resultado es: "+Resultado);
        } else if (rbRestar.isChecked()==true) {
            int Resultado = n1 - n2;
            txtResultado.setText("El resultado es: "+Resultado);
        } else if (rbDividir.isChecked()==true) {
            int Resultado = n1 / n2;
            txtResultado.setText("El resultado es: "+Resultado);
        } else if (rbMultiplicar.isChecked()==true) {
            int Resultado = n1 * n2;
            txtResultado.setText("El resultado es: "+Resultado);
        }
    }
}
